package th.ac.su.bmime2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class DetailActivity : AppCompatActivity() {
    var bmi:Double? = null;
    var case:String? = null;
    var height:Double? = null;
    var weight:Double? = null;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)


        var txvBmi = findViewById<TextView>(R.id.txvBmi);
        var txvCase = findViewById<TextView>(R.id.txvCase);
        var txvHW = findViewById<TextView>(R.id.txvHW);
        var btnShare = findViewById<Button>(R.id.btnShare);
        var btnClose = findViewById<Button>(R.id.btnClose);
        bmi = intent.getDoubleExtra("bmi",0.0);
        case = intent.getStringExtra("case");
        height = intent.getDoubleExtra("height",0.0);
        weight = intent.getDoubleExtra("weight",0.0);

        txvBmi.text = String.format("%.2f", bmi);
        txvCase.text = case;
        txvHW.text = "(height: "+String.format("%.1f", height)+" weight: "+String.format("%.1f", weight)+")";

        btnShare.setOnClickListener {
            var intent = Intent();
            intent.action = Intent.ACTION_SEND;
            intent.putExtra(Intent.EXTRA_TEXT,"My BMI is "+String.format("%.1f", bmi)+"("+case.toString()+")");
            intent.type = "plan/text";
            startActivity(Intent.createChooser(intent,"Share"));
        }
        btnClose.setOnClickListener {
            finish()
        }


    }
}