package th.ac.su.bmime2


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn = findViewById<Button>(R.id.btn);
        var edtH = findViewById<EditText>(R.id.edtH);
        var edtW = findViewById<EditText>(R.id.edtW);
//
        var case:String? = null;
        val CHANGE_REQUEST_CODE = 2000;
        btn.setOnClickListener {
            var height = edtH.text.toString().toFloat()/100.0;
            var weight = edtW.text.toString().toFloat();
//
            var bmi:Double = weight/(height*height);
//
            if(bmi<=18.5){
                case = "Underweight";

            }else if(bmi>18.5 && bmi <= 25){
                case = "Healthy";
            }else if(bmi>25 && bmi < 30){
                case = "Overweight";
            }else if(bmi>=30){
                case = "Obese";
            }else
                case = "not found"
//            txtCheck.text = "Your bmi is "+String.format("%.2f", bmi);


            var intent = Intent(this,DetailActivity::class.java);

            intent.putExtra("weight",weight/1.0);
            intent.putExtra("height",height);
            intent.putExtra("bmi",bmi);
            intent.putExtra("case",case);
            startActivityForResult(intent,CHANGE_REQUEST_CODE)
        }

    }
}